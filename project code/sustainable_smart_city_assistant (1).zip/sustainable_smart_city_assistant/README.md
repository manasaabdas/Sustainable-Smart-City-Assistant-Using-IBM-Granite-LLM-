# Sustainable Smart City Assistant

## Frontend (React + Tailwind CSS)
- Run `npm install` inside the frontend directory
- Then `npm run dev`

## Backend (FastAPI)
- Run `pip install -r requirements.txt` inside backend directory
- Then `uvicorn main:app --reload`

## Chatbot
- Chat endpoint is at `http://localhost:8000/chat`
- Placeholder for IBM Granite LLM integration