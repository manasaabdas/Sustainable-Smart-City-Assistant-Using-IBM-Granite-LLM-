from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class User(BaseModel):
    email: str
    password: str

@app.post("/register")
async def register(user: User):
    with open("backend/users.json", "r+") as file:
        users = json.load(file)
        if any(u["email"] == user.email for u in users):
            return {"success": False, "message": "User already exists"}
        users.append(user.dict())
        file.seek(0)
        json.dump(users, file)
    return {"success": True}

@app.post("/login")
async def login(user: User):
    with open("backend/users.json", "r") as file:
        users = json.load(file)
        for u in users:
            if u["email"] == user.email and u["password"] == user.password:
                return {"success": True, "user": {"email": u["email"]}}
    return {"success": False}

@app.post("/chat")
async def chat_endpoint(data: dict):
    return {"response": f"Granite LLM response to: '{data['message']}'"}