import React, { useState } from 'react';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';

const App = () => {
  const [user, setUser] = useState(null);
  const [showRegister, setShowRegister] = useState(false);

  const handleLogout = () => setUser(null);

  if (!user) {
    return showRegister
      ? <Register onRegister={() => setShowRegister(false)} />
      : <Login onLogin={setUser} />;
  }

  return <Dashboard user={user} onLogout={handleLogout} />;
};

export default App;