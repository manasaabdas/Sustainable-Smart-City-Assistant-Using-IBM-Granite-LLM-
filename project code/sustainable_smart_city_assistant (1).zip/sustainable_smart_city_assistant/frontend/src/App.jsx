import React, { useState } from 'react';

const App = () => {
  const [input, setInput] = useState("");
  const [response, setResponse] = useState("");

  const handleSubmit = async () => {
    const res = await fetch("http://localhost:8000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setResponse(data.response);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Sustainable Smart City Assistant</h1>
      <textarea value={input} onChange={(e) => setInput(e.target.value)} className="w-full p-2 border rounded" rows="4" />
      <button onClick={handleSubmit} className="mt-2 px-4 py-2 bg-blue-600 text-white rounded">Ask</button>
      {response && <div className="mt-4 p-4 bg-green-100 border rounded">{response}</div>}
    </div>
  );
};

export default App;